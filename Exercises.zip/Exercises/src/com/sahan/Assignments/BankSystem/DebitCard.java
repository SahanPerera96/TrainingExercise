package com.sahan.Assignments.BankSystem;
// created by Sahan Perera

public class DebitCard extends VisaCard {

    @Override
    public void withdraw() {
        isDebitCardType();
        super.withdraw();

    }

}

package com.sahan.Assignments.BankSystem;
// created by Sahan Perera

import java.util.Scanner;

public class VisaCard extends Credit {
    String accountPIN = "";
    String creditPIN = "123456";
    String debitPIN = "654321";
    boolean accountValidity = false;

    @Override
    public void withdraw() {
        if(accountValidity){
            super.withdraw();
        }else {
            cardValidation();
        }

    }

    public boolean cardValidation(){


        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter PIN No : ");
        String pin = scanner.next();

        switch (cardType) {

            case creditCard:
                accountPIN = creditPIN;
                pinVerify(pin);
                break;
            case debitCard:
                accountPIN = debitPIN;
                pinVerify(pin);
                break;
            default:
                System.out.println();


        }

        return accountValidity;
    }
    public void pinVerify(String pin){
        if(pin.equals(accountPIN)){
            System.out.println("Card Valid");
            accountValidity = true;
            withdraw();


        }else {
            System.out.println("Card Invalid");
            accountValidity = false;
            cardValidation();



        }
    }




}

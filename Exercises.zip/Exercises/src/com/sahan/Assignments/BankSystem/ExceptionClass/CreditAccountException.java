package com.sahan.Assignments.BankSystem.ExceptionClass;
// created by Sahan Perera

public class CreditAccountException extends Exception {

    public CreditAccountException(String message) {
        super(message);

    }
}

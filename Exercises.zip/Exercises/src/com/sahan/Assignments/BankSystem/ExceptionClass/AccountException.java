package com.sahan.Assignments.BankSystem.ExceptionClass;
// created by Sahan Perera

public class AccountException extends Exception {

    public AccountException(String message) {
        super(message);
    }
}

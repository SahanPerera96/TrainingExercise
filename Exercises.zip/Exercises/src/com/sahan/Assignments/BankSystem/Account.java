package com.sahan.Assignments.BankSystem;
// created by Sahan Perera

import com.sahan.Assignments.BankSystem.ExceptionClass.AccountException;

import java.util.Scanner;

public class Account {

    float amount = 0;

    float accountBalance = 100000;
    float withdrawnAmount  = 0;

    boolean isWithdrawAble = false;

    float creditLimit = 10000;
    float creditedAmount = 0;

    public void withdraw(){

        try {
            checkBalance();
        }catch (AccountException e){
            System.out.println(e.getMessage());
        }
//        if(isWithdrawAble){
//            accountBalance = accountBalance - amount;
//            withdrawnAmount = withdrawnAmount + amount;
//            System.out.println("Withdrawal Successful");
//            System.out.println("------------------------------------------");
//            System.out.println("Account Balance : \t" + accountBalance);
//            System.out.println("Withdrawn Amount : \t" + amount);
//            System.out.println("Total withdrawals amount: \t" + withdrawnAmount);
//            System.out.println();
//
//
//        }else {
//            System.out.println("Withdrawal Failed");
//
//        }
    }
    private void checkBalance() throws AccountException{

        if(accountBalance>0){

            if(amount <= accountBalance){
                isWithdrawAble = true;
                accountBalance = accountBalance - amount;
                withdrawnAmount = withdrawnAmount + amount;
                System.out.println("Withdrawal Successful");
                System.out.println("------------------------------------------");
                System.out.println("Account Balance : \t" + accountBalance);
                System.out.println("Withdrawn Amount : \t" + amount);
                System.out.println("Total withdrawals amount: \t" + withdrawnAmount);
                System.out.println();

            }else{
                isWithdrawAble = false;
                throw new AccountException("Account balance is less than Withdraw Amount");
            }
        }else {
            isWithdrawAble = false;
            throw new AccountException("Account Balance is Zero");
        }
    }
}

package com.sahan.Assignments.BankSystem;
// created by Sahan Perera

public class Current extends Account {


}

package com.sahan.Assignments.BankSystem;
// created by Sahan Perera

public class CreditCard extends VisaCard{

    @Override
    public void withdraw() {
        isCreditCardType();
        super.withdraw();

    }
}

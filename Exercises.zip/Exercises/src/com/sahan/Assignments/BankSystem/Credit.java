package com.sahan.Assignments.BankSystem;
// created by Sahan Perera

import com.sahan.Assignments.BankSystem.ExceptionClass.CreditAccountException;

import java.util.Scanner;

public class Credit extends Account{
    String accountPIN = "123456";
    boolean accountValidity = false;
    final String creditCard = "Credit";
    final String debitCard = "Debit";
    boolean isCredit = false;
    boolean isDebit = false;
    String cardType = "";



    @Override
    public void withdraw() {
        accountValidation();


    }

    public void accountValidation() {

        try {
            switch (cardType) {
                case creditCard:
                    getWithdrawAmount();
                    isCreditLimitReached();
                    break;
                case debitCard:
                    getWithdrawAmount();
                    super.withdraw();
                    repeat();
                    break;
                default:
                    System.out.println();
            }
        }catch (CreditAccountException e){
            System.out.println(e.getMessage());
            accountValidation();
        }

    }

    public void repeat(){
        System.out.print("Do you want to withdraw Again? (y/n) : ");
        Scanner scanner = new Scanner(System.in);
        String choice = scanner.next();
        switch (choice) {
            case "y":
                withdraw();
                break;
            case "n":
                System.out.println("Transaction Closed. Thank you! ");
                break;
            default:
                System.out.println("Incorrect value. Enter y for yes and n for no");
                repeat();
        }
    }

    public void isCreditLimitReached(){
        if(amount<= creditLimit){
            creditedAmount = creditedAmount+ amount;
            if(creditedAmount <= creditLimit){
//                super.withdraw();
                System.out.println("Credit Withdrawal Successful");
                System.out.println("------------------------------------------");
                System.out.println("Credit Account Balance : \t" + (creditLimit - creditedAmount));
                System.out.println("Withdrawn Amount : \t" + amount);
                System.out.println("Total withdrawals amount: \t" + creditedAmount);
                System.out.println();
                repeat();
            }else {
                System.out.println("You had reached Maximum Credit Limit.");
                repeat();
            }

        }else{
            System.out.println("Withdrawal greater than Credit Limit");
            accountValidation();
        }

    }

    public void getWithdrawAmount() throws CreditAccountException{
        // ^\\d+ says that input starts with a digit 0-9,
        // ()? may/or may not occur
        // \\. allows one period in input

        Scanner scanner = new Scanner(System.in);
        System.out.print("Enter Amount to Withdraw : ");
        String scanerInput;
        scanerInput = scanner.next();
        if(String.valueOf(scanerInput).matches("^\\d+(\\.\\d+)?")) {
            //okay
            amount = Float.parseFloat(scanerInput);

        } else {
           throw new CreditAccountException("Enter a Valid Amount to Withdraw");
        }

    }

    public void isCreditCardType(){
        isCredit = true;
        isDebit = false;
        cardType = creditCard;
    }

    public void isDebitCardType(){

        isCredit = false;
        isDebit = true;
        cardType = debitCard;
    }

}

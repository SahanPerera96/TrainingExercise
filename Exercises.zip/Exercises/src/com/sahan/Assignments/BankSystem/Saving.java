package com.sahan.Assignments.BankSystem;
// created by Sahan Perera

public class Saving extends Account {



}

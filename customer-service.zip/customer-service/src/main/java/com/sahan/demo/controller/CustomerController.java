package com.sahan.demo.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.sahan.demo.modal.Customer;
import com.sahan.demo.service.CustomerService;

@RestController
@RequestMapping(value = "/customercare")
public class CustomerController {
	
	@Autowired
	CustomerService customerService;
	
	@RequestMapping(value = "/customer", method = RequestMethod.POST)
	public Customer saveCustomerDetails(@RequestBody Customer customer) {
		
		return customerService.saveCustomerDetails(customer);
	}
	

}

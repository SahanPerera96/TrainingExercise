package com.sahan.demo.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.sahan.demo.modal.Customer;
import com.sahan.demo.modal.Mobile;
import com.sahan.demo.repository.CustomerRepository;

@Service
public class CustomerServiceImpl implements CustomerService {
	
	@Autowired
	CustomerRepository customerRepository;
	@Override
	public Customer saveCustomerDetails(Customer customer) {
		
		for(Mobile mobile: customer.getMobiles()) {
			mobile.setCustomer(customer);
		}
		// TODO Auto-generated method stub
		return customerRepository.save(customer);
	}

}

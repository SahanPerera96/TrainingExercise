package com.sahan.demo.service;

import com.sahan.demo.modal.Customer;

public interface CustomerService {
	
	Customer saveCustomerDetails(Customer customer);

}

package com.sahan;

import java.time.LocalDate;
import java.time.Month;
import java.time.Period;
import java.util.List;
import java.util.stream.Collectors;

public class Process {

    public static void main(String[] args) {

        System.out.println("First Example");
        List<Employee> list = Employee.getAllEmployees().stream()
                .map(employee -> new Employee( employee.getName(),employee.getMarks()*2))
                .collect(Collectors.toList());

        System.out.println(list);
        System.out.println();
        System.out.println("Second Example");
        List<Employee> list2 = Employee.getAllEmployees().stream()
                .filter(employee -> employee.getName().contains("i"))
                .map(employee -> new Employee( employee.getName(),employee.getMarks()*3))
                .collect(Collectors.toList());

        System.out.println(list2);
        System.out.println();
        System.out.println("Second Example with count");
        long count = Employee.getAllEmployees().stream()
                .filter(employee -> employee.getName().contains("i"))
                .map(employee -> new Employee( employee.getName(),employee.getMarks()*3))
                .count();
        System.out.println(count);



        LocalDate today = LocalDate.now();                          //Today's date

        System.out.println("Third Example");
        List<Student> studentList = Student.getAllStudents().stream()
                .filter(student -> Period.between(student.getDateOfBirth(),today).getYears()>18)
                .collect(Collectors.toList());

        System.out.println(studentList);
        System.out.println("Student list count : " + studentList.size());

    }
}

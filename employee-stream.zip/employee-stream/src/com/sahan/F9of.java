package com.sahan;

import java.util.stream.Stream;

public class F9of {

    public static void main(String[] args) {

        Stream.of(1,3,6,4,2,7,8,5).sorted().forEach(System.out::println);

        Integer[] integers = {1,3,6,4,2,7,8,54};
        Stream<Integer> integerStream = Stream.of(integers);
        integerStream.sorted(Integer::compareTo).forEach(System.out::println);
    }
}

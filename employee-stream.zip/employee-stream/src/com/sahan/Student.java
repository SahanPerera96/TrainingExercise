package com.sahan;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.Month;
import java.util.ArrayList;
import java.util.List;

public class Student {
    String name;
    LocalDate dateOfBirth;

    public Student(String name, LocalDate dateOfBirth) {
        this.name = name;
        this.dateOfBirth = dateOfBirth;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public LocalDate getDateOfBirth() {
        return dateOfBirth;
    }

    public void setDateOfBirth(LocalDate dateOfBirth) {
        this.dateOfBirth = dateOfBirth;
    }

    public static List<Student> getAllStudents(){
        List<Student> studentList = new ArrayList<>();
        studentList.add(new Student("Sahan",LocalDate.of(1996, 12, 13)));
        studentList.add(new Student("Peter",LocalDate.of(2000, 1, 1)));
        studentList.add(new Student("Angalo",LocalDate.of(2015, 5, 13)));
        studentList.add(new Student("Sean",LocalDate.of(2011, 6, 6)));
        studentList.add(new Student("Ron",LocalDate.of(2001, 11, 12)));
        studentList.add(new Student("Harry",LocalDate.of(1990, 10, 9)));
        studentList.add(new Student("Walter",LocalDate.of(1985, 9, 22)));
        studentList.add(new Student("Shan",LocalDate.of(1990, 7, 1)));
        studentList.add(new Student("Waruna",LocalDate.of(1994, 5, 14)));
        studentList.add(new Student("Oshan",LocalDate.of(1996, 6, 19)));
        studentList.add(new Student("Sahan",LocalDate.of(1990, 12, 11)));



        return studentList;
    }

    @Override
    public String toString() {
        return name+" "+dateOfBirth;
    }
}

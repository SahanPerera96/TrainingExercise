package com.sahan;

import java.util.Comparator;
import java.util.List;
import java.util.stream.Collectors;

public class Foreach {

    public static void main(String[] args) {

        Employee.getAllEmployees().forEach(employee ->
                System.out.println(employee.getName())
        );

        Employee.getAllEmployees().stream()
                .filter(employee -> employee.getName().length() >= 5 )
                .map(employee -> new Employee(
                        employee.getName().toUpperCase().charAt(0)+
                                employee.getName().substring(1,employee.getName().length()),
                        employee.getMarks()*2))
                .sorted((o1, o2) -> -o1.getName().compareTo(o2.getName()))
//                .sorted(Comparator.comparing(Employee::getName).reversed())
                .forEach(System.out::println);

    }
}

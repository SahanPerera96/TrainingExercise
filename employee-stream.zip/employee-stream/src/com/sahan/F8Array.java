package com.sahan;

import java.util.Arrays;

public class F8Array {

    public static void main(String[] args) {
        Employee[] employees = Employee.getAllEmployees().stream().toArray(Employee[]::new);

        Arrays.stream(employees).forEach(System.out::println);
    }
}

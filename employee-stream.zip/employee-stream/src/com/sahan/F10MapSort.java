package com.sahan;

import java.util.*;
import java.util.stream.Collectors;

public class F10MapSort {

    public static void main(String[] args) {
        Map<String,Integer> students = new HashMap<>();
        students.put("krish",100);
        students.put("nuwan",90);
        students.put("bhagya",60);
        students.put("hasini",95);
        students.put("suranga",65);
        students.put("erandaka",55);

        Integer passMark = 60;

        students.entrySet()
                .stream()
                .filter(entry -> entry.getValue() > passMark)
                .sorted(Map.Entry.<String, Integer>comparingByValue().reversed() ).collect(Collectors.toList())
                .stream()
                .forEach(s -> System.out.println(s.getKey()));

        List<String> string = new ArrayList<>();
        students.entrySet()
                .stream()
                .filter(entry -> entry.getValue() > passMark)
                .sorted(((o1, o2) -> -o1.getValue().compareTo(o2.getValue())))
                .peek(entry -> string.add(entry.getKey())).collect(Collectors.toList());

        System.out.println(string);
        System.out.println("--------------------------");
        Map<String,String> city = new HashMap<>();
        city.put("krish","colombo");
        city.put("nuwan","ja-ela");
        city.put("bhagya","wattala");
        city.put("hasini","gale");
        city.put("suranga","kandy");
        city.put("erandaka","sal");

        Integer maxLength = 4;

        city.entrySet()
                .stream()
                .filter(entry -> entry.getValue().toString().length() > maxLength)
                .sorted(Map.Entry.<String, String>comparingByValue() )
                .map(entry -> entry.getValue().toUpperCase().charAt(0)+ entry.getValue().substring(1,entry.getValue().length()))

                .forEach(System.out::println);

        System.out.println("--------------------------");

        Map<Integer,String> vehicles = new HashMap<>();
        vehicles.put(10,"Car");
        vehicles.put(50,"SUV");
        vehicles.put(20,"Jeep");
        vehicles.put(12,"Bus");
        vehicles.put(15,"Ship");
        vehicles.put(16,"Lorry");
        vehicles.put(4,"Cycle");

        List<Integer> no = new ArrayList<>();
        List<String> vehicle = new ArrayList<>();

        vehicles.entrySet()
                .stream()
                .sorted(Map.Entry.<Integer, String>comparingByKey() )
                .peek(entry -> no.add(entry.getKey()))
//                .parallelStream()
                .filter(entry -> entry.getValue() != "Ship")
                .sorted(Map.Entry.<Integer, String>comparingByValue().reversed() )
                .peek(entry -> vehicle.add(entry.getValue())).collect(Collectors.toList())
                .parallelStream();
//                .forEach();

//                .parallelStream()


        no.forEach(System.out::println);
        System.out.println("--------------------------");

        vehicle.forEach(System.out::println);
//
//        vehicles.entrySet()
//                .stream()
//                .sorted(Map.Entry.<Integer, String>comparingByKey().reversed() ).collect(Collectors.toList())
//                .stream()
//                .forEach(s -> System.out.println(s.getKey()))
//        ;

    }
}

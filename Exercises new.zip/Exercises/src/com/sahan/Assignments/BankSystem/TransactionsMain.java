package com.sahan.Assignments.BankSystem;
// created by Sahan Perera

public class TransactionsMain {

//    public static void main(String[] args) {
////         write your code here
//
//        Account account = new CreditCard();
//        account.withdraw(); // pin no is "123456" for credit card
//
//        Account account = new DebitCard();
//        account.withdraw(); // pin no is "654321" for debit card
//
//
//    }
}

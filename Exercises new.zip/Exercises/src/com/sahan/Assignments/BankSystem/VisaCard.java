package com.sahan.Assignments.BankSystem;
// created by Sahan Perera

import com.sahan.Assignments.BankSystem.ExceptionClass.AccountException;
import com.sahan.Assignments.BankSystem.ExceptionClass.CreditAccountException;

import java.io.InvalidObjectException;

public class VisaCard extends Credit {
//    String accountPIN = "";
//    String creditPIN = "123456";
//    String debitPIN = "654321";
//    boolean accountValidity = false;
//
//    @Override
//    public void withdraw() {
//        if(accountValidity){
//            super.withdraw();
//        }else {
//            cardValidation();
//        }
//
//    }
//
//    public boolean cardValidation(){
//
//
//        Scanner scanner = new Scanner(System.in);
//        System.out.print("Enter PIN No : ");
//        String pin = scanner.next();
//
//        switch (cardType) {
//
//            case creditCard:
//                accountPIN = creditPIN;
//                pinVerify(pin);
//                break;
//            case debitCard:
//                accountPIN = debitPIN;
//                pinVerify(pin);
//                break;
//            default:
//                System.out.println();
//
//
//        }
//
//        return accountValidity;
//    }
//    public void pinVerify(String pin){
//        if(pin.equals(accountPIN)){
//            System.out.println("Card Valid");
//            accountValidity = true;
//            withdraw();
//
//
//        }else {
//            System.out.println("Card Invalid");
//            accountValidity = false;
//            cardValidation();
//
//
//
//        }
//    }
//
//


    @Override
    public void withdraw(double amount) {

        System.out.println("Withdraw made from Credit Account Class");
    }

    public boolean validateCardNumber(String cardNumber) throws InvalidObjectException, CreditAccountException {

        try {
            try {
                if(validateAccount(cardNumber)){
                    if(cardNumber.startsWith("812")){
                        return true;
                    }else {
    //            throw new Exception((new InvalidObjectException("Invalid card number")));
                        throw new InvalidObjectException("Invalid card number");

                    }
                }else {
                    throw new CreditAccountException("Invalid Account Number");
                }
            } catch (AccountException e) {
                throw new CreditAccountException("Account validation failed",e);
            }
        }catch (IllegalArgumentException iae){
            throw new CreditAccountException("Account Validation falied",iae);
        }


    }
}

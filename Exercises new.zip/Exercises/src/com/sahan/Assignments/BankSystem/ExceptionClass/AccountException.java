package com.sahan.Assignments.BankSystem.ExceptionClass;
// created by Sahan Perera

public class AccountException extends Exception { // Exception

//    public AccountException(String message) {
//        super(message);
//    }


    public AccountException() {
        super();
    }

    public AccountException(String message) {
        super(message);
    }

    public AccountException(String message, Throwable cause) {
        super(message, cause);
    }
}

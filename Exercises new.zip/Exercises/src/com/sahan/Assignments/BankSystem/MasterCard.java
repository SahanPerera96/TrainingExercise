package com.sahan.Assignments.BankSystem;
// created by Sahan Perera

public class MasterCard extends Credit {


}

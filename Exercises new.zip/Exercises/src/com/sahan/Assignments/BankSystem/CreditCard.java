package com.sahan.Assignments.BankSystem;
// created by Sahan Perera

import com.sahan.Assignments.BankSystem.ExceptionClass.AccountException;
import com.sahan.Assignments.BankSystem.ExceptionClass.CreditAccountException;

import java.io.InvalidObjectException;

public class CreditCard extends VisaCard{
//
//    @Override
//    public void withdraw() {
//        isCreditCardType();
//        super.withdraw();
//
//    }

    @Override
    public void withdraw(double amount) {

        try {
//            try {
                if (validateCardNumber("8126")){// 8126578
                    super.withdraw(amount);
                }
//            } catch (CreditAccountException e) {
//                e.printStackTrace();
//            }
        } catch (InvalidObjectException e) {
            e.printStackTrace();
        } catch (CreditAccountException e) {
            e.printStackTrace();
        }
    }
}

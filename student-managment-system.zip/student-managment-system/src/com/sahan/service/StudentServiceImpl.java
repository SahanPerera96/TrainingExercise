package com.sahan.service;

import java.util.List;

import com.sahan.modal.Student;
import com.sahan.repository.HibernateStudentRepository;
import com.sahan.repository.StudentRepository;

public class StudentServiceImpl implements StudentService  {
	

	public StudentServiceImpl(StudentRepository repository) {
		this.repository = repository;
	}


	StudentRepository repository; // = new HibernateStudentRepository();
	
	
	public StudentRepository getRepository() {
		return repository;
	}


	public void setRepository(StudentRepository repository) {
		this.repository = repository;
	}


		/* (non-Javadoc)
		 * @see com.sahan.StudentService#fetchAllStudents()
		 */
		@Override
		public List<Student> fetchAllStudents(){
			
			return repository.fetchAllStudents();
		}
	
}

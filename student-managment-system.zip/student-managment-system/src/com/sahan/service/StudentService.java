package com.sahan.service;

import java.util.List;

import com.sahan.modal.Student;

public interface StudentService {

	List<Student> fetchAllStudents();
	

}
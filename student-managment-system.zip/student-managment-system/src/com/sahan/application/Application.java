package com.sahan.application;

import java.util.ArrayList;
import java.util.List;

import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.sahan.modal.Student;
import com.sahan.service.StudentService;
import com.sahan.service.StudentServiceImpl;

public class Application {

	public static void main(String[] args) {
		
		ApplicationContext context = new ClassPathXmlApplicationContext("applicationContex.xml");
		StudentService service = context.getBean("studentService",StudentService.class);
		
//		StudentService service = new StudentServiceImpl();
		List<Student> students = new ArrayList<Student>();
		
		students = service.fetchAllStudents();
//		System.out.println(students.get(0).getName());
		for (int i = 0; i < students.size(); i++) {
			System.out.println(students.get(i).getName());
			
		}
		
	}
}

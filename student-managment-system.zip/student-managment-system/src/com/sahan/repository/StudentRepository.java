package com.sahan.repository;

import java.util.List;

import com.sahan.modal.Student;

public interface StudentRepository {

	List<Student> fetchAllStudents();

}
package com.sahan.repository;

import java.util.ArrayList;
import java.util.List;

import com.sahan.modal.Student;

public class JPAStudentRepository implements StudentRepository {

	/* (non-Javadoc)
	 * @see com.sahan.StudentRepository#fetchAllStudents()
	 */
	@Override
	public List<Student> fetchAllStudents(){
		List<Student> students = new ArrayList<>();
		Student student = new Student();
		student.setId(1);
		student.setName("Sahan");
		students.add(student);
		return students;
	}
}

package com.evictory.inventorycloud.modal;

public class CurrentStock {

}

package com.evictory.inventorycloud.modal;

public class StockLog {

}

package Sahan.Encapsulation;

import java.util.ArrayList;
import java.util.List;

public class School {

    List<Student> students;

    {
        students = new ArrayList<Student>();
    }

    public School() {

    }

    //inner class encapsulation method 2

    public void addStudents(Student student) {
        students.add(student);
    }

    public void getStudents() {

        for (Student student : students) {
            System.out.println(student.toString());
        }

    }

//    public School(String grade, int noOfStudents) {
//        for (int i = 0; i < noOfStudents; i++) {
//            students.add(new Student(grade));
//        }
//    }

    // Inner method encapsulation  method 3
    public void schoolInnerMethod() {

        class schoolChecker { // declare a class inside a method
            public void checker(String name) {
                if ("Sahan".equalsIgnoreCase(name)) {
                    System.out.println(" Valid Student");
                } else {
                    System.out.println(" Not a valid Student");
                }
            }
        }

        new schoolChecker().checker("Sahan"); // class  called inside the method

    }

    // Anonymous class encapsulation method 4
    // next way to encapsulate is remove class and assign it as an object and call it in the end after declaring
    public void schoolAnonymousMethod() {
        new Object() {
            public void checker(String name) {
                if ("Sahan".equalsIgnoreCase(name)) {
                    System.out.println(" Valid Student");
                } else {
                    System.out.println(" Not a valid Student");
                }
            }
        }.checker("Nimal");
    }

    // Inner class
    class Student {
        String name;

        public Student(String name) {
            this.name = name;
        }
        @Override
        public String toString() {
            return " Student "+ name ;
        }

    }
}

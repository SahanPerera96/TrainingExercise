package Sahan.Encapsulation;

public class Main {

    public static void main(String[] args) {
	// write your code here

        // Encapsulation method 1 using access modifiers Private,Public, protected
        Student student = new Student();
        // setting values of the variables
        student.setId(1);
        student.setName("Sahan");
        student.setAge(22);

        // Displaying values of the variables
        System.out.println("Encapsulation method 1");
        System.out.println(" Student ID : " + student.getId());
        System.out.println(" Student Name: " + student.getName());
        System.out.println(" Student Age: " + student.getAge());


        // Encapsulation method 2  using Inner classes encapsulation
        System.out.println();
        System.out.println("Encapsulation method 2");
        School school = new School();
        // setting values of the variables
        school.addStudents(school.new Student("Sahan"));
        school.addStudents(school.new Student("Kasun"));
        school.addStudents(school.new Student("Nimal"));

        // Displaying values of the variables
        school.getStudents();

        // Encapsulation method 3  using Inner classes encapsulation
        System.out.println();
        System.out.println("Encapsulation method 3");
        School school1  = new School();
        school1.schoolInnerMethod();

        // Encapsulation method 4  using Anonymous class
        System.out.println();
        System.out.println("Encapsulation method 4");
        School school3 = new School();
        school3.schoolAnonymousMethod();

    }
}

insert into book_seq (next_val) values (1)

insert into school(id, city, name) values("SCH_001","Wattala", "sahan")
insert into school(id, city, name) values("SCH_002","ja ela", "saman")

insert into school(id, city, name) values("SCH_003","kadana", "jony")
insert into school(id, city, name) values("SCH_004","seduwa", "tom")

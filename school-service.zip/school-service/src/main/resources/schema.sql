drop table if exists book_seq;
drop table if exists school;


create table book_seq (
        next_val bigint

    );

create table school (
        id varchar(255) not null,
        city varchar(255),
        name varchar(255),
        primary key (id)
    ); 


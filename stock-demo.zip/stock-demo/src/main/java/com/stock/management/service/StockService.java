package com.stock.management.service;

import java.util.List;

import com.stock.management.modal.OpenStock;
import com.stock.management.modal.OpenStockDetails;

public interface StockService {
	OpenStock saveOpenStock(OpenStock openStock);
    List<OpenStock> fetchAllOpenStock();
    
    OpenStock createOpenStock(OpenStock openStock);
    OpenStockDetails createOpenStockDetails(Integer id, OpenStockDetails details);
}

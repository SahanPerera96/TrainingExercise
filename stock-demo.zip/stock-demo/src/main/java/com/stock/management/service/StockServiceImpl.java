package com.stock.management.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.annotation.Bean;
import org.springframework.stereotype.Service;

import com.stock.management.modal.OpenStock;
import com.stock.management.modal.OpenStockDetails;
import com.stock.management.repository.OpenStockDetailsRepository;
import com.stock.management.repository.StockRepository;

@Service

public class StockServiceImpl implements StockService {
		
		
	 	@Autowired
	 	StockRepository stockRepository;
	 	
	 	@Autowired
	 	OpenStockDetailsRepository openStockDetailsRepository;
	   

	    @Override
	    public OpenStock saveOpenStock(OpenStock openStock) {

	        for(OpenStockDetails openStockDetails:openStock.getOpenStockDetails()) {
	            openStockDetails.setOpenStock(openStock);
	        }
	        return stockRepository.save(openStock);
	    }

	    @Override
	    public List<OpenStock> fetchAllOpenStock() {
	        return stockRepository.findAll();
	    }
	    
	    @Override
	    public OpenStock createOpenStock(OpenStock openStock) {
	    	    return stockRepository.save(openStock);
	    }
	    
	    @Override
	    public OpenStockDetails createOpenStockDetails(Integer id, OpenStockDetails details  ) {
	    		
	    		
	    		List<OpenStock> openStock =  fetchAllOpenStock();
	    		System.out.println("asdfgsdfbirhjbfihegrcaifuihsd" + id +"value");
	    		for (int i = 0; i < openStock.size(); i++) {
					if (openStock.get(i).getId() == id) {
						details.setOpenStock(openStock.get(i));
						System.out.println("asdfgsdfbirhjbfihegrcaifuihsd" + i +"value");
					}
				}
	    		System.out.println("asdfgsdfbirhjbfihegrcaifuihsd");
	    	    return openStockDetailsRepository.save(details);
	    }
}

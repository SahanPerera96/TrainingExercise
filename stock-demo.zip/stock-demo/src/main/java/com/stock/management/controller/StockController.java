package com.stock.management.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.stock.management.modal.OpenStock;
import com.stock.management.modal.OpenStockDetails;
import com.stock.management.service.StockService;

@RestController
@RequestMapping(value = "/demo")
public class StockController {
	@Autowired
    StockService stockService;

    @RequestMapping(value = "/openStockAll", method = RequestMethod.POST)
    public OpenStock saveOpenStock(@RequestBody OpenStock openStock) {

        return stockService.saveOpenStock(openStock);
    }

    @RequestMapping(value = "/openStockAll", method = RequestMethod.GET)
    public List<OpenStock> fetchAllOpenStock() {

        return stockService.fetchAllOpenStock();
    }
    
    // add only new open stock  record
    @RequestMapping(value = "/openStock", method = RequestMethod.POST)
    public OpenStock createOpenStock(@RequestBody OpenStock openStock) {

        return stockService.createOpenStock(openStock);
    }
    
 // add only new open stock  detail record
//    @RequestMapping(value = "/openStockDetails", method = RequestMethod.POST)
//    public OpenStockDetails createOpenStockDetails(@RequestBody Integer Osid,
//    		@RequestBody Integer itemId, @RequestBody Integer quantity) {
//    	
//        return stockService.createOpenStockDetails(Osid,itemId,quantity);
//    }
    @RequestMapping(value = "/openStockDetails/{id}", method = RequestMethod.POST)
    public OpenStockDetails createOpenStockDetails(@PathVariable Integer id, @RequestBody OpenStockDetails details) {
    	System.out.println("asdfgsdfbirhjbfihegrcaifuihsd" + id +"valueid");
        return stockService.createOpenStockDetails(id, details);
    }
}
